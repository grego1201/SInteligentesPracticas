#!/usr/bin/env python
# -*- coding: utf-8 -*-

''' Moviemientos posibles ''' 
MOVE_UP = "Up"
MOVE_DOWN = "Down"
MOVE_LEFT = "Left"
MOVE_RIGHT = "Right"

class estado():
	def __init__(self):
		self.estado=[]

	def getEstado(self):
		return self.estado

	def setEstado(self, estado):
		self.estado = estado

	def movimientos_validos(self, coor, movimiento):
		valido=True

		if (coor[0]==0 and movimiento==MOVE_LEFT) or (coor[0]==self.columnas-1 and movimiento==MOVE_RIGHT) or (coor[1]==0 and movimiento==MOVE_UP) or (coor[1]==self.filas-1 and movimiento==MOVE_DOWN):
			valido=False

		return valido
