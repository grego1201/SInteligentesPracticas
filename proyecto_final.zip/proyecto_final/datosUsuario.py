#!/usr/bin/env python
# -*- coding: utf-8 -*-

from os import listdir

class datosUsuario():
	def __init__(self):
		pass

	def obtenerDatosUsuario(self):

		lista_imagenes=[]
		centinela=False
		columnas=0
		filas=0
		seleccionada=""
		estadoInicial=""

		while centinela==False:
			print "*** Indicaciones ***\nLos archivos deben contener en el nombre el tamaño\nde división, formato: nombreColumnasxFilas.png"
			print "Ya que esas serán las filas y columnas por las que se dividirá"
			print "Imagenes disponibles para el puzzle:"
			contador=0

			for archivo in listdir("."):
				if archivo.find('.png')!=-1:
					print "\t"+str(contador)+"-"+archivo
					lista_imagenes.append(archivo)
					contador+=1

			while centinela==False:
				eleccion=raw_input("Seleccione un número de foto para el puzzle:")
				if eleccion.isdigit():
					eleccion=int(eleccion)
					if eleccion<len(lista_imagenes) and eleccion>-1:
						print "Imagen seleccionada: "+lista_imagenes[eleccion]
						seleccionada=lista_imagenes.pop(eleccion)
						centinela=True

			columnas, filas =self.obtenerColFil(seleccionada)

			if filas=="" or filas==0:
				print "Algo ha fallado, compruebe que el nombre del archivo cumple el formato!!"
				centinela=False
			else:
				centinela=True
				print "División en:"+str(columnas)+"x"+str(filas)
			
				inicial=False
				contador=0
				print "Imagenes disponibles para el estado inicial:"
				for i in lista_imagenes:
					print "\t"+str(contador)+"-"+i
					contador+=1

				while inicial==False:
					eleccion=raw_input("Seleccione un número de foto para el estado inicial:")
					if eleccion.isdigit():
						eleccion=int(eleccion)
						if eleccion<len(lista_imagenes) and eleccion>-1:
							print "Estado inicial seleccionado: "+lista_imagenes[eleccion]+"\n"
							estadoInicial=lista_imagenes[eleccion]
							inicial=True
			

		return seleccionada,estadoInicial,columnas,filas

	def obtenerColFil(self, seleccion):
		lista=list(seleccion)
		subcadena=""
		columnas=0
		filas=0

		for i in lista:
			if i.isdigit():
				subcadena+=str(i)
			elif i=="x" and subcadena!="":
				columnas=subcadena
				subcadena=""
		
		filas=subcadena
		return columnas,filas


	




	




