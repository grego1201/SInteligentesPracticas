#!/usr/bin/env python
# -*- coding: utf-8 -*-

class pieza():
	def __init__(self):
		self.id=None
		self.coordenadas=None
		self.pivote=None

	def crearPieza(self, ids, coor):
		self.id= ids
		self.coordenadas=coor
		self.pivote= False
	
	def setCoordenadas(self, coor):
		self.coordenadas=coor

	def getCoordenadas(self):
		return self.coordenadas

	def setId(self, ids):
		self.id=ids

	def getId(self):
		return self.id

	def setPivote(self, pivote):
		self.pivote=pivote

	def getPivote(self):
		return self.pivote