#!/usr/bin/env python
# -*- coding: utf-8 -*-

''' Moviemientos posibles ''' 
MOVE_UP = "Up"
MOVE_DOWN = "Down"
MOVE_LEFT = "Left"
MOVE_RIGHT = "Right"

class estado():
	def __init__(self,filas, columnas):
		self.filas=filas
		self.columnas=columnas
		self.tablero=[]
		self.pivote=None #id del pivote en este estado
		self.posPivAnterior=None

	def crearEstado(self, tablero, pivote):
		self.tablero=tablero
		self.pivote=pivote

	
	def movimientos(self, pivote):
		movimientos = []

		coor=self.tablero[pivote].getCoordenadas()
		
		if coor[0]>0:
			movimientos.append(MOVE_LEFT)
		if coor[0]<self.columnas-1:
			movimientos.append(MOVE_RIGHT)
		if coor[1]>0:
			movimientos.append(MOVE_UP)
		if coor[1]<self.filas-1:
			movimientos.append(MOVE_DOWN)

		return movimientos
		
	def getIdsTablero(self):
		cadena=""
		for i in self.tablero:
			cadena=cadena+str(i.getId())+" "

		return cadena

	def addPieza(self, pieza):
		self.estado.append(pieza)

	def getTablero(self):
		return self.tablero

	def setTablero(self, estado):
		self.estado = estado

	def getPivote(self):
		return self.pivote

	def setPivote(self, pivote):
		self.pivote = pivote

	def setPosPivAnterior(self, pivoteAnterior):
		self.posPivAnterior=pivoteAnterior

	def getPostPivAnterior(self):
		return self.posPivAnterior



