#!/usr/bin/env python
# -*- coding: utf-8 -*-

from estado import estado

class problema():
	def __init__(self, estadoObjetivo, estadoInicial,espacioEstados):
		self.estadoInicial = estadoInicial
		self.estadoObjetivo = estadoObjetivo
		self.espacioEstados=espacioEstados
		
	def esObjetivo(self, estado): #determina si un estado recibido es el objetivo o no
		objetivo = True
		for i in range(0,len(estado.getTablero())):
			if estado.getTablero()[i].getId()!=self.estadoObjetivo.getTablero()[i].getId():
				i=len(estado.getTablero())
				objetivo = False

		return objetivo

	def heuristica(self,estado):
		desordenadas=0

		for i in range(0,len(self.estadoObjetivo.getTablero())):
			if estado.getTablero()[i].getId()!=self.estadoObjetivo.getTablero()[i].getId():
				desordenadas+=1

		return desordenadas

	def getEstadoInicial(self):
		return self.estadoInicial