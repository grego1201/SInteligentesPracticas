#!/usr/bin/env python
# -*- coding: utf-8 -*-

class nodo():
	def __init__(self, padre, estado, costo, accion, valor, posPiv):
		self.padre = padre
		self.estado = estado

		if padre is not None:
			self.costo = padre.costo + valor
			self.profundidad = padre.profundidad + 1
		else:
			self.costo = costo
			self.profundidad = 0


		self.accion = accion
		self.valor = self.profundidad
		self.posPiv = posPiv
