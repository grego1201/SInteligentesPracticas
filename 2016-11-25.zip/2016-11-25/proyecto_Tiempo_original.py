#!/usr/bin/env python
# -*- coding: utf-8 -*-

import random
import copy
from time import time
import resource
import signal, os
import Tkinter as tk
import tkMessageBox
from PIL import Image, ImageTk
import sortedcontainers

from nodo import nodo
from estadoC import estadoC
from fronteraC import fronteraC


MOVE_UP = "Up"
MOVE_DOWN = "Down"
MOVE_LEFT = "Left"
MOVE_RIGHT = "Right"

''' -------------- LAS PIEZAS NO ALMACENAN IMAGENES, SOLO UN ID QUE RELACIONA LA PIEZA CON UNA IMAGEN ---------------'''


''' -------- Clase puzzle, contiene la ejecucion principal ---------- '''
''' ----------------------------------------------------------------- '''
class app(tk.Frame):

	def __init__(self,imagen_o,imagen_p, columnas, filas):
		tk.Frame.__init__(self)
		self.grid()

		self.columnas=columnas
		self.filas=filas

		self.imagen_o = imagen_o
		self.imagen_p = imagen_p


		self.limitarMemoria(1<<30)

		if self.obtener_datos(imagen_o, imagen_p):
			self.crear_tablero_original()
			if self.comprobar_imagenes():

				'''
				estadoInicial = estadoC(self.tablero_puzzle, 4, 4, self.posPivote())
				nInicial = nodo(None, estadoInicial, 1, None, 1, self.posPivote())
				suc = estadoInicial.sucesores()
				for x in suc:
					for y in x[1].estado:
						if y['pivote']:
							print (y['coordenadas'])

				frontera = fronteraC()

				frontera.insertar(nInicial)
				inicio = time()
				nodos = 0
				try:
					while not frontera.isEmpty():
						nodoActual = frontera.eliminar()
						estado = nodoActual.estado
						listaSucesores = estado.sucesores()
						for x in listaSucesores:
							nuevoNodo=nodo(nodoActual, x[1], 1, x[0], 1, self.posPivote())
							nodos +=1
							frontera.insertar(nuevoNodo)
						if frontera.tamanio() > 2000000:
							break
				except MemoryError:
					print "petado de memoria"

				finally:

					print time()-inicio
					print nodos'''

				estadoInicial = estadoC(self.tablero_puzzle, 4, 4, self.posPivote())
				nInicial = nodo(None, estadoInicial, 1, None, 1, self.posPivote())
				suc = estadoInicial.sucesores()

				frontera = fronteraC()

				frontera.insertar(nInicial)

				solucion = False
				i=0

				while not solucion and not frontera.isEmpty():
					i+=1
					print "una iteracion mas " + str(i)
					nodoActual = frontera.eliminar()
					estado = nodoActual.estado
					if self.esObjetivo(estado.getEstado()):
						print "es objetivo"
						solucion=True
					else:
						listaSucesores = estado.sucesores()
						for x in listaSucesores:
							nuevoNodo=nodo(nodoActual, x[1], 1, x[0], 1, self.posPivote())
							frontera.insertar(nuevoNodo)




				self.crear_canvas()
				self.mostrar()


			else:
				print ("--- La imágenes no son iguales ---")



	def limitarMemoria(self, tamMax):
		soft, hard = resource.getrlimit(resource.RLIMIT_AS)
		resource.setrlimit(resource.RLIMIT_AS, (tamMax, hard))

	def obtener_datos(self, img_o, img_p):
		try:
			self.img_original=Image.open(img_o) #carga la imagen inicial
			self.img_puzzle= Image.open(img_p) #carga la imagen con el estado inicial

			#establece el ancho y alto del tablero
			self.ancho_tablero=self.img_original.size[0]
			self.alto_tablero=self.img_original.size[1]

			#establece el alto y ancho de las piezas
			self.ancho_pieza=self.ancho_tablero / self.columnas
			self.alto_pieza=self.alto_tablero / self.filas

			return True
		except:
			print("La imagen seleccionada no se encuentra en el directorio")
			return False

	def crear_tablero_original(self):
		self.tablero_original = [] #almacena el tablero conforme estaría resuelto, almacena tuplas (id,coordenadas), las coordenadas x,y simulan una matriz
		self.tablero_puzzle=[] #almacena el tablero conforme al estado inicial, almacena tuplas (id,coordenadas),las coordenadas x,y simulan una matriz

		self.listaImg_Original=[] #almacena la imagen original cortada en trozos, sirve para compararla con la otra imagen y para generar una imagen png nueva
		self.listaImg_Puzzle=[] #almacena la imagen del estado inicial en trozos, para compararla con la original, luego se vacia
		self.imagenes=[] #almacena los trozos igual que en listaImg_Original pero en forma PhotoImage, necesario para mostrarlos en el canvas

		contadorPivote=0
		ids=0

		for x in xrange(self.columnas):
			for y in xrange(self.filas):
				x0 = x * self.ancho_pieza
				y0 = y * self.alto_pieza
				x1 = x0 + self.ancho_pieza
				y1 = y0 + self.alto_pieza

				#foto original
				if x==0 and y==0: #para la imagen 0.0 pone una en negro

					self.listaImg_Original.append(Image.new("RGB",(self.ancho_pieza,self.alto_pieza),"black"))
					self.imagenes.append(ImageTk.PhotoImage(self.listaImg_Original[ids]))
				else:
					self.listaImg_Original.append(self.img_original.crop((x0, y0, x1, y1)))
					self.imagenes.append(ImageTk.PhotoImage(self.listaImg_Original[ids]))

				self.tablero_original.append(self.nueva_pieza(ids,(x,y))) #crea una nueva pieza que almacena la id y la posicion x,y que tendrá

				''' Las ids de las piezas hacen referencia al indice de las listas de imagenes: ListaImg_Original e imagenes
					de forma que no almacenemos imagenes en cada pieza, si no solo un identificador de la imagen real, así ocupa menos
					espacio cara a la generación de estados, y en caso de querer mortrarla o crear una imagen solo hay que emplear
					esa id como indice de las listas '''


				#foto puzzle
				self.listaImg_Puzzle.append(self.img_puzzle.crop((x0, y0, x1, y1)))
				self.tablero_puzzle.append(self.nueva_pieza(None,(x,y))) #crea una nueva pieza sin id, con la posicion que tendrá
				ids+=1

		#establece el pivote en el tablero original
		self.tablero_original[0]['pivote']=True
		self.pivote=0

	def crear_canvas(self):
	    args = dict(width=self.ancho_tablero, height=self.alto_tablero)
	    self.canvas = tk.Canvas(self, **args)
	    self.canvas.grid()

	def comprobar_imagenes(self):
		iguales= 0
		''' tenemos que hacer poda, daba problemas '''
		#se comparan las imagenes trozo a trozo
		for x in range(0, len(self.listaImg_Original)):
			for y in range(0,len(self.listaImg_Puzzle)):
					if self.listaImg_Original[x] == self.listaImg_Puzzle[y]: # si los dos trozos son iguales...
						iguales = iguales + 1

						self.tablero_puzzle[y]['id']=self.tablero_original[x]['id']	#establece a la pieza desordenada la id que corresponde con la imagen original
						self.listaImg_Puzzle[y]=[] # por si hay muchas imagenes dle mismo color, para que no vuelva a comparar y asignar el id a la misma, se elimina de la lista

						if x == 0: #establece el pivote en el tablero puzzle (ya que cuando x sea 0, en el tablero original(y por tanto en la lista original) será la imagen negra)
							self.tablero_puzzle[y]['pivote']=True
							self.pivote=y

						break

		self.listaImg_Puzzle=[] #vacia la lista que no va a volver a utilizarse para liberar memoria

		#si el numero de piezas iguales coincide con el tamaño de la matriz (filas*columnas) es que las dos imagenes son iguales
		if iguales==self.columnas*self.filas:
			return True
		else:
			return False

	def nueva_pieza(self, ids, coor):
		piece = {'id': ids, 'coordenadas'  : coor, 'pivote' : False}
		return piece

	def mostrar(self):
		index = 0

		for x in xrange(self.columnas):
			for y in xrange(self.filas):
				x1 = x * self.ancho_pieza
				y1 = y * self.alto_pieza

				#obtiene la imagen correspondiente  a la id almacenada y la muestra en la posicion x,y
				image = self.imagenes[self.tablero_puzzle[index]['id']]
				self.pintar(x1,y1,image)

				index += 1

	def pintar(self,x,y,imagen):
		self.canvas.create_image(x, y, image=imagen, anchor=tk.NW)

	def mover(self):
		indice=0
		coorX=coorY=0

		aleatorio=random.randint(0,3)
		mov=''

		if aleatorio ==0:
			mov = MOVE_UP
			coorX=self.tablero_puzzle[self.pivote]['coordenadas'][0]
			coorY=self.tablero_puzzle[self.pivote]['coordenadas'][1]-1
		if aleatorio ==1:
			mov= MOVE_DOWN
			coorX=self.tablero_puzzle[self.pivote]['coordenadas'][0]
			coorY=self.tablero_puzzle[self.pivote]['coordenadas'][1]+1
		if aleatorio ==2:
			mov= MOVE_LEFT
			coorX=self.tablero_puzzle[self.pivote]['coordenadas'][0]-1
			coorY=self.tablero_puzzle[self.pivote]['coordenadas'][1]
		if aleatorio ==3:
			mov= MOVE_RIGHT
			coorX=self.tablero_puzzle[self.pivote]['coordenadas'][0]+1
			coorY=self.tablero_puzzle[self.pivote]['coordenadas'][1]

		#comprueba si el pivote que está en x,y puede moverse a la posicion definida anteriormente
		if self.movimientos_validos(self.tablero_puzzle[self.pivote]['coordenadas'],mov):

			#busca la pieza que corresponde a la posicion a la que va a moverse el pivote
			for i in self.tablero_puzzle:
				if i['coordenadas']==(coorX,coorY):
					break
				indice+=1

			#las intercambia
			self.tablero_puzzle = self.cambiar_piezas(self.pivote, indice, self.tablero_puzzle)

			#pinta ambas piezas en la nueva posicion
			x = int(self.tablero_puzzle[self.pivote]['coordenadas'][0]) * self.ancho_pieza
			y = int(self.tablero_puzzle[self.pivote]['coordenadas'][1]) * self.alto_pieza
			aux=self.pintar(x, y, self.imagenes[ self.tablero_puzzle[self.pivote]['id']])

			x = int(self.tablero_puzzle[indice]['coordenadas'][0]) * self.ancho_pieza
			y = int(self.tablero_puzzle[indice]['coordenadas'][1]) * self.alto_pieza
			aux=self.pintar(x, y, self.imagenes[self.tablero_puzzle[indice]['id']])

			self.pivote=indice
			self.after(1000,self.mover)
		else:
			self.after(0,self.mover)



	def cambiar_piezas(self, id1, id2, estado):

		lista_aux=copy.deepcopy(estado) #si no se copia la lista así, lo que hace es apuntar a su zona de memoria
		aux = lista_aux[id1]
		coor2=lista_aux[id2]['coordenadas']

		lista_aux[id1]=lista_aux[id2]
		lista_aux[id1]['coordenadas']=aux['coordenadas']

		lista_aux[id2]=aux
		lista_aux[id2]['coordenadas']=coor2

		return lista_aux


	def crear_imagen(self):

		imagen = Image.new("RGB",(self.ancho_tablero,self.alto_tablero),"white")#crea una imagen en blanco sobre la que se pegarán todas las demas
		indice=0

		for x in xrange(self.columnas):
			for y in xrange(self.filas):
				x0 = x * self.ancho_pieza
				y0 = y * self.alto_pieza

				#recorre la lista de imagenes obteniendo las imagenes en el orden que están en el tablero de ese instante, y las pega juntas
				imagen.paste(self.listaImg_Original[self.tablero_puzzle[indice]['id']],(x0,y0))
				indice+=1

		imagen.save("imagenGenerada.png")

	def esObjetivo(self, estado): #determina si un estado recibido es el objetivo o no
		objetivo = True
		for i in range(0,len(estado)):
			if estado[i]['id']!=self.tablero_original[i]['id']:
				i=len(estado)
				objetivo = False

		if objetivo:
			print("Es objetivo")
		else:
			print("No es objetivo")

		return objetivo

	def posPivote(self):
		for i in self.tablero_puzzle:
			if i['pivote']:
				return i['coordenadas']
