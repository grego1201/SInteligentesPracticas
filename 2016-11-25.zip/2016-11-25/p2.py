#!/usr/bin/env python
# -*- coding: utf-8 -*-

from proyecto_Tiempo_original import app


imagen = app('AlhambraInicialPuzzle4x4.png','IntermedioAlhambra41.png', 4,4)
imagen.master.title('prueba')
imagen.mainloop()
