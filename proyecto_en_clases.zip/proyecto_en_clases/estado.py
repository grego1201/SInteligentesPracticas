#!/usr/bin/env python
# -*- coding: utf-8 -*-

''' Moviemientos posibles ''' 
MOVE_UP = "Up"
MOVE_DOWN = "Down"
MOVE_LEFT = "Left"
MOVE_RIGHT = "Right"

class estado():
	def __init__(self,filas, columnas):
		self.filas=filas
		self.columnas=columnas
		self.estado=[]
		self.pivote=None #id del pivote en este estado

	def crearEstado(self, estado, pivote):
		self.estado=estado
		self.pivote=pivote


	''' no se si todo esto va aqui o en el espacio de estados '''
	def movimientos(self, pivote):
		movimientos = []

		coor=self.estado[pivote].getCoordenadas()
		
		if coor[0]>0:
			movimientos.append(MOVE_LEFT)
		if coor[0]<self.columnas-1:
			movimientos.append(MOVE_RIGHT)
		if coor[1]>0:
			movimientos.append(MOVE_UP)
		if coor[1]<self.filas-1:
			movimientos.append(MOVE_DOWN)

		return movimientos

	def movimientos_validos(self, coor, movimiento):
		valido=True

		if (coor[0]==0 and movimiento==MOVE_LEFT) or (coor[0]==self.columnas-1 and movimiento==MOVE_RIGHT) or (coor[1]==0 and movimiento==MOVE_UP) or (coor[1]==self.filas-1 and movimiento==MOVE_DOWN):
			valido=False

		return valido
		
	''' hasta aqui dudo'''



	def addPieza(self, pieza):
		self.estado.append(pieza)

	def getEstado(self):
		return self.estado

	def setEstado(self, estado):
		self.estado = estado

	def getPivote(self):
		return self.pivote

	def setPivote(self, pivote):
		self.pivote = pivote