#!/usr/bin/env python
# -*- coding: utf-8 -*-

from estado import estado

class problema():
	def __init__(self, estadoObjetivo, estadoInicial,espacioEstados):
		self.estadoInicial = estadoInicial
		self.estadoObjetivo = estadoObjetivo
		self.espacioEstados=espacioEstados
		
	def esObjetivo(self, estado): #determina si un estado recibido es el objetivo o no
		objetivo = True
		for i in range(0,len(estado.getTablero())):
			if estado.getTablero()[i].getId()!=self.estadoObjetivo.getTablero()[i].getId():
				i=len(estado.getTablero())
				objetivo = False

		'''if objetivo:
			print("Es objetivo")
		else:
			print("No es objetivo")'''

		return objetivo

	def getEstadoInicial(self):
		return self.estadoInicial