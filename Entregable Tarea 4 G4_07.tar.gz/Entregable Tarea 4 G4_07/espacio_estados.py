#!/usr/bin/env python
# -*- coding: utf-8 -*-
import copy

from pieza import pieza
from estado import estado

# EsValido() no hace falta porque todo estado va a ser valido siempre, ya que
# se comprueba que ambas imagenes sean iguales
# EsObjetivo está en "Problema"

class espacio_estados():

	def __init__(self,filas,columnas):
		#necesario para mover piezas para generar sucesores
		self.filas=filas
		self.columnas=columnas

	def sucesores(self, estado, posPiv): #devuelve los estados sucesores desde un estado dado
		#determina qué movimientos puede hacer, el coste y el estado resultante de ello
		#return (acc1,estado1,costAcc1)...(accM,estadoM,costAccM)
		costeAcc = 1
		lista_sucesores=[]

		movimientos= estado.movimientos(posPiv)

		for i in movimientos:	
			if i=="Up":
				sucesor=self.nuevo_sucesor(i,(self.cambiar_piezas(posPiv,(posPiv-1),estado)),costeAcc,posPiv-1)
			elif i=="Down":
				sucesor=self.nuevo_sucesor(i,(self.cambiar_piezas(posPiv,(posPiv+1),estado)),costeAcc,posPiv+1)
			elif i=="Left":
				sucesor=self.nuevo_sucesor(i,(self.cambiar_piezas(posPiv,(posPiv-self.filas),estado)),costeAcc,posPiv-self.filas)
			elif i=="Right":
				sucesor=self.nuevo_sucesor(i,(self.cambiar_piezas(posPiv,(posPiv+self.filas),estado)),costeAcc,posPiv+self.filas)
			
			lista_sucesores.append(sucesor)

		return lista_sucesores

	def nuevo_sucesor(self, movimiento, estado, coste, posPivote): #almacena también el pivote aunque no se pida para no tener que buscarlo en cada estado luego
		sucesor = {'movimiento': movimiento, 'estado'  : estado, 'coste' : coste, 'posPivote': posPivote}
		return sucesor
	
	def cambiar_piezas(self, id1, id2, estado):

		lista_aux=copy.deepcopy(estado) #si no se copia la lista así, lo que hace es apuntar a su zona de memoria
		aux = lista_aux.getTablero()[id1]
		coor2=lista_aux.getTablero()[id2].getCoordenadas()
		
		lista_aux.setPivote(id2)
		lista_aux.setPosPivAnterior(id1)

		lista_aux.getTablero()[id1]=lista_aux.getTablero()[id2]
		lista_aux.getTablero()[id1].setCoordenadas(aux.getCoordenadas())

		lista_aux.getTablero()[id2]=aux
		lista_aux.getTablero()[id2].setCoordenadas(coor2)

		return lista_aux
